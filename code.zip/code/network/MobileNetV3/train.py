import dataread
import config
import torch
from torch import nn, optim
from torch.utils.data import DataLoader, WeightedRandomSampler
import time, csv, os
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score
from torchvision import models
import torch.nn as nn

def get_mobilenetv3_model(num_classes=2, pretrained=False, version='small'):
    if version == 'small':
        model = models.mobilenet_v3_small(pretrained=pretrained)
    elif version == 'large':
        model = models.mobilenet_v3_large(pretrained=pretrained)
    else:
        raise ValueError(f"不支持的MobileNetV3版本: {version}. 请选择 'small' 或 'large'")

    num_features = model.classifier[3].in_features
    model.classifier[3] = nn.Linear(num_features, num_classes)

    return model

def get_efficientnet_model(num_classes=2, pretrained=True, version='b0'):
    efficientnet_models = {
        'b0': models.efficientnet_b0,
        'b1': models.efficientnet_b1,
        'b2': models.efficientnet_b2,
        'b3': models.efficientnet_b3,
        'b4': models.efficientnet_b4,
        'b5': models.efficientnet_b5,
        'b6': models.efficientnet_b6,
        'b7': models.efficientnet_b7,
    }

    if version not in efficientnet_models:
        raise ValueError(f"不支持的EfficientNet版本: {version}. 请选择 'b0' 到 'b7'")

    model = efficientnet_models[version](pretrained=pretrained)
    num_features = model.classifier[1].in_features
    model.classifier[1] = nn.Linear(num_features, num_classes)

    return model

def get_vgg_model(num_classes=2, pretrained=True):
    model = models.vgg16(pretrained=pretrained)
    model.classifier[6] = nn.Linear(model.classifier[6].in_features, num_classes)
    return model

def save_list_to_csv(input_list, filename):
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        for item in input_list:
            writer.writerow([item])

def plot_func(data, ylabel):
    plt.plot(range(len(data)), data)
    plt.xlabel("Epoch")
    plt.ylabel(ylabel)
    plt.title(f"{ylabel} Curve")
    plt.show()

def log(msg, path):
    print(msg)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(msg + '\n')

def count_label_distribution(dataset, name, log_path):
    good = bad = fake_bad = 0

    for sample in dataset:
        _, label, _, is_fake = sample
        if label == 0:
            good += 1
        else:
            if is_fake:
                fake_bad += 1
            else:
                bad += 1

    total = good + bad + fake_bad
    log(f"{name}集: good={good}, bad={bad}, fake_bad={fake_bad}, 总计={total}", log_path)

log_path = config.train_parameters["log1"]
os.makedirs(os.path.dirname(log_path), exist_ok=True)

with open(log_path, 'w', encoding='utf-8') as f:
    f.write("训练日志开始\n")

start = time.time()
device = torch.device(config.train_parameters["device"])

model = get_mobilenetv3_model(num_classes=2, pretrained=False, version='small').to(device)

optimizer = optim.SGD(model.parameters(), lr=config.train_parameters["learning_rate"])

class_weights = torch.tensor(config.train_parameters["loss_weights"], dtype=torch.float32).to(device)
loss_func = nn.CrossEntropyLoss(weight=class_weights)

train_set = dataread.load_dataset()
train_dataset, val_dataset = dataread.split_dataset(train_set)

count_label_distribution(train_dataset, "训练", log_path)
count_label_distribution(val_dataset, "验证", log_path)

if config.train_parameters.get("use_class_weight", False):
    labels = [train_dataset[i][1] for i in range(len(train_dataset))]
    class_weights = config.train_parameters.get("class_weights", [1.0, 1.0])
    class_weights_tensor = torch.tensor(class_weights, dtype=torch.float32)
    log(f"使用的类别权重: {class_weights_tensor.tolist()}", log_path)
    sample_weights = [float(class_weights_tensor[label]) for label in labels]
    sampler = WeightedRandomSampler(sample_weights, num_samples=len(train_dataset), replacement=True)
    train_loader = DataLoader(train_dataset, batch_size=config.train_parameters["batch"], sampler=sampler, drop_last=True)
else:
    train_loader = DataLoader(train_dataset, batch_size=config.train_parameters["batch"], shuffle=True, drop_last=True)

val_loader = DataLoader(val_dataset, batch_size=config.train_parameters["batch"], shuffle=False, drop_last=True)

val_losses, val_accuracies = [], []
val_best = float('inf')

for epoch in range(config.train_parameters["epoch"]):
    model.train()
    loss_sum, correct, total = 0.0, 0, 0

    for batch in train_loader:
        x, y = batch[0].to(device), batch[1].to(device)
        if y.dim() == 2:
            y = y.squeeze(1)
        optimizer.zero_grad()
        pred = model(x)
        loss = loss_func(pred, y.long())
        loss.backward()
        optimizer.step()
        loss_sum += loss.item()
        correct += (pred.argmax(1) == y).sum().item()
        total += y.size(0)
        avg_loss = loss_sum / len(train_dataset)
    train_acc = correct / total if total != 0 else 0.0
    log(f"[Epoch {epoch+1}] Train Loss: {avg_loss:.8f}, Accuracy: {train_acc:.4f}", log_path)

    model.eval()
    val_loss, val_correct, val_total = 0.0, 0, 0
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for batch in val_loader:
            x, y = batch[0].to(device), batch[1].to(device)
            if y.dim() == 2:
                y = y.squeeze(1)
            pred = model(x)
            val_loss += loss_func(pred, y.long()).item()
            val_correct += (pred.argmax(1) == y).sum().item()
            val_total += y.size(0)
            all_preds.extend(pred.argmax(1).cpu().numpy())
            all_labels.extend(y.cpu().numpy())

    val_loss_avg = val_loss / len(val_loader) if len(val_loader) != 0 else 0.0
    val_acc = val_correct / val_total if val_total != 0 else 0.0
    val_losses.append(val_loss_avg)
    val_accuracies.append(val_acc)

    if len(all_labels) > 0:
        precision = precision_score(all_labels, all_preds, pos_label=1)
        recall = recall_score(all_labels, all_preds, pos_label=1)
        f1 = f1_score(all_labels, all_preds, pos_label=1)
    else:
        precision = recall = f1 = 0.0

    log(f"[Epoch {epoch+1}] Validation Loss: {val_loss_avg:.8f}, Accuracy: {val_acc:.4f}", log_path)
    log(f"[Epoch {epoch+1}] Bad Class Metrics - Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {f1:.4f}", log_path)

    if (epoch + 1) % 200 == 0:
        path = os.path.join(config.train_parameters["save_model_dir"], f"model_epoch_{epoch+1}.pth")
        torch.save(model.state_dict(), path)
        log(f"Model saved to {path}", log_path)

end = time.time()
log(f"训练完成，共耗时 {(end - start):.2f} 秒", log_path)

save_list_to_csv(val_losses, os.path.join(config.train_parameters["save_dir"], "val_losses.csv"))
save_list_to_csv(val_accuracies, os.path.join(config.train_parameters["save_dir"], "val_accuracies.csv"))
plot_func(val_losses, "Validation Loss")
plot_func(val_accuracies, "Validation Accuracy")