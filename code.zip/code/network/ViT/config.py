train_parameters = {
    "epoch": 8000,
    "batch": 64,
    "learning_rate": 0.00001,
    "layer_times": 2,
    "device":"cuda:2",
    "train_pro": 0.8,
    "eval_pro": 0.1,
    "num_classes": 2,

    "base_dir": "/ptset/",
    "dataset_dir": r"/ViT/set/dataset",
    "mini_dataset_dir": r"/ViT/set/mini_dataset",
    "save_model_dir": r"/ViT/model",
    "save_dir": r"/ViT/plot",
    "log1": r"/ViT/log/log.txt",

    "use_fake_datas": True,
    "use_mini": False,
    "fake_data_train_ratio": 0.9,
    "loss_weights": [1, 1],
    "use_class_weight": True,
    "class_weights": [1, 1],
}
