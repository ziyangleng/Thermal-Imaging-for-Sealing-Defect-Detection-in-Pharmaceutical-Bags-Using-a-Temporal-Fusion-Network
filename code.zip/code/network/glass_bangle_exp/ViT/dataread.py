import torch
from torch.utils.data import Dataset, random_split, ConcatDataset
import os
from torchvision import transforms
from PIL import Image

class My_Dataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.img_paths = []
        self.labels = []
        self._load_data()

    def _load_data(self):
        label_map = {'good': 0, 'broken': 1, 'defect': 2}

        for label_name, label in label_map.items():
            label_dir = os.path.join(self.root_dir, label_name)
            for img_name in os.listdir(label_dir):
                if img_name.endswith('.jpg'):
                    img_path = os.path.join(label_dir, img_name)
                    self.img_paths.append(img_path)
                    self.labels.append(label)

    def __len__(self):
        return len(self.img_paths)

    def __getitem__(self, idx):
        img_path = self.img_paths[idx]
        label = self.labels[idx]

        img = Image.open(img_path).convert('RGB')

        if self.transform:
            img = self.transform(img)

        return img, label

def split_dataset(dataset, train_pro=0.8):
    total_size = len(dataset)
    train_size = int(total_size * train_pro)
    val_size = total_size - train_size

    generator = torch.Generator().manual_seed(42)
    train_set, val_set = random_split(dataset, [train_size, val_size], generator=generator)

    return train_set, val_set

def load_dataset():
    base = '/home/leng/Dataset_open/glass_bangle'

    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])

    dataset = My_Dataset(root_dir=base, transform=transform)

    train_set, val_set = split_dataset(dataset)

    return train_set, val_set