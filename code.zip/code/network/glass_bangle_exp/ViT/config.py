train_parameters = {
    "epoch": 8000,
    "batch": 64,
    "learning_rate": 0.00001,
    "layer_times": 2,
    "device":"cuda:0",
    "train_pro": 0.8,
    "eval_pro": 0.2,
    "num_classes": 3,

    "base_dir": "/Dataset_open/glass_bangle",
    "dataset_dir": r"/ViT/set/dataset",
    "save_dir": r"/Dataset_open/glass_bangle_exp/ViT/plot",
    "log1": r"/Dataset_open/glass_bangle_exp/ViT/log/log.txt",

    "fake_data_train_ratio": 0.9,
    "loss_weights": [1, 1, 1],  
    "use_class_weight": False,
    "class_weights": [1, 1, 1],  
}

