#
train_parameters = {
    "epoch": 8000,
    "batch": 64,
    "learning_rate": 0.0002,
    "layer_times": 1,
    "device": "cuda:1",
    "train_pro": 0.8,
    "eval_pro": 0.2,
    "num_classes": 2,

    "base_dir": "/ptset/",
    "save_model_dir": r"/TMFFNet/model",
    "save_dir": r"/TMFFNet/plot",
    "log1": r"/TMFFNet/log/log.txt",

    "use_fake_datas": True,
    "use_mini": False,
    "fake_data_train_ratio": 0.6,

    "use_fake_datas": True,
    "use_mini": False,
    "fake_data_train_ratio": 0.9,
    "loss_weights": [1, 1],
    "use_class_weight": True,
    "class_weights": [1, 1],
}
