from net import Net
import dataread
import config
import torch
from torch import nn, optim
from torch.utils.data import DataLoader, WeightedRandomSampler
import time, csv, os
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score


def save_list_to_csv(input_list, filename):
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        for item in input_list:
            writer.writerow([item])


def plot_func(data, ylabel):
    plt.plot(range(len(data)), data)
    plt.xlabel("Epoch")
    plt.ylabel(ylabel)
    plt.title(f"{ylabel} Curve")
    plt.show()


def log(msg, path):
    print(msg)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(msg + '\n')


def count_label_distribution(dataset, name, log_path):
    good = bad = fake_bad = 0

    if hasattr(dataset, 'labels') and hasattr(dataset, 'is_fake'):
        for label, is_fake in zip(dataset.labels, dataset.is_fake):
            if label == 0:
                good += 1
            else:
                if is_fake:
                    fake_bad += 1
                else:
                    bad += 1
    else:
        for i in range(len(dataset)):
            _, _, label, _, is_fake = dataset[i]
            if label == 0:
                good += 1
            else:
                if is_fake:
                    fake_bad += 1
                else:
                    bad += 1

    total = good + bad + fake_bad
    log(f"{name}集: good={good}, bad={bad}, fake_bad={fake_bad}, 总计={total}", log_path)


def train_one_epoch(model, train_loader, optimizer, loss_func, device, epoch, log_path):
    model.train()
    loss_sum, correct, total = 0.0, 0, 0

    for batch in train_loader:
        m1, m2, y = batch[0].to(device), batch[1].to(device), batch[2].to(device)
        if y.dim() == 2:
            y = y.squeeze(1)
        optimizer.zero_grad()
        pred = model(m1, m2)
        loss = loss_func(pred, y.long())
        loss.backward()
        optimizer.step()
        loss_sum += loss.item()
        correct += (pred.argmax(1) == y).sum().item()
        total += y.size(0)

    avg_loss = loss_sum / len(train_loader)
    train_acc = correct / total if total != 0 else 0.0
    log_msg = f"[Epoch {epoch}] Train Loss: {avg_loss:.4f}, Accuracy: {train_acc:.4f}"
    log(log_msg, log_path)
    return avg_loss, train_acc


def validate_one_epoch(model, val_loader, loss_func, device, epoch, log_path):
    model.eval()
    val_loss, val_correct, val_total = 0.0, 0, 0
    all_preds = []
    all_labels = []
    real_bad_correct = 0
    real_bad_total = 0

    with torch.no_grad():
        for batch in val_loader:
            m1, m2, y = batch[0].to(device), batch[1].to(device), batch[2].to(device)
            is_fake = batch[4].to(device)
            if y.dim() == 2:
                y = y.squeeze(1)
            pred = model(m1, m2)
            val_loss += loss_func(pred, y.long()).item()
            val_correct += (pred.argmax(1) == y).sum().item()
            val_total += y.size(0)
            all_preds.extend(pred.argmax(1).cpu().numpy())
            all_labels.extend(y.cpu().numpy())

            real_bad_mask = (y == 1) & (~is_fake.bool())
            if real_bad_mask.any():
                real_bad_correct += (pred.argmax(1)[real_bad_mask] == y[real_bad_mask]).sum().item()
                real_bad_total += real_bad_mask.sum().item()

    val_loss_avg = val_loss / len(val_loader) if len(val_loader) != 0 else 0.0
    val_acc = val_correct / val_total if val_total != 0 else 0.0

    real_bad_acc = real_bad_correct / real_bad_total if real_bad_total != 0 else 0.0

    precision = 0.0
    recall = 0.0
    f1 = 0.0
    if len(all_labels) > 0 and any(label == 1 for label in all_labels):
        precision = precision_score(all_labels, all_preds, pos_label=1, zero_division=0)
        recall = recall_score(all_labels, all_preds, pos_label=1, zero_division=0)
        f1 = f1_score(all_labels, all_preds, pos_label=1, zero_division=0)

    log_msg = f"[Epoch {epoch}] Validation Loss: {val_loss_avg:.4f}, Accuracy: {val_acc:.4f}"
    log(log_msg, log_path)

    log_msg = f"[Epoch {epoch}] Bad Class Metrics - Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {f1:.4f}"
    log(log_msg, log_path)

    return val_loss_avg, val_acc, precision, recall, f1


log_path = config.train_parameters["log1"]
os.makedirs(os.path.dirname(log_path), exist_ok=True)
with open(log_path, 'w', encoding='utf-8') as f:
    f.write("训练日志开始\n")

start = time.time()
device = torch.device(config.train_parameters["device"])
model = Net().to(device)
optimizer = optim.SGD(model.parameters(), lr=config.train_parameters["learning_rate"])

class_weights = torch.tensor(config.train_parameters["loss_weights"], dtype=torch.float32).to(device)
loss_func = nn.CrossEntropyLoss(weight=class_weights)

train_set = dataread.load_dataset_by_config()
train_dataset, val_dataset, _ = dataread.split_dataset(train_set)

count_label_distribution(train_dataset, "训练", log_path)
count_label_distribution(val_dataset, "验证", log_path)

if config.train_parameters.get("use_class_weight", False):
    labels = []
    for i in range(len(train_dataset)):
        _, _, label, _, _ = train_dataset[i]
        labels.append(label)

    class_weights = config.train_parameters.get("class_weights", [1.0, 1.0])
    class_weights_tensor = torch.tensor(class_weights, dtype=torch.float32)
    log(f"使用的类别权重: {class_weights_tensor.tolist()}", log_path)
    sample_weights = [float(class_weights_tensor[label]) for label in labels]
    sampler = WeightedRandomSampler(sample_weights, num_samples=len(train_dataset), replacement=True)
    train_loader = DataLoader(train_dataset, batch_size=config.train_parameters["batch"], sampler=sampler,
                              drop_last=True)
else:
    train_loader = DataLoader(train_dataset, batch_size=config.train_parameters["batch"], shuffle=True, drop_last=True)

val_loader = DataLoader(val_dataset, batch_size=config.train_parameters["batch"], shuffle=False, drop_last=True)

train_losses = []
train_accuracies = []
val_losses = []
val_accuracies = []
precisions = []
recalls = []
f1s = []

val_best = float('inf')
best_model_epoch = 0

for epoch in range(1, config.train_parameters["epoch"] + 1):
    train_loss, train_acc = train_one_epoch(model, train_loader, optimizer, loss_func, device, epoch, log_path)
    train_losses.append(train_loss)
    train_accuracies.append(train_acc)

    val_loss, val_acc, precision, recall, f1 = validate_one_epoch(model, val_loader, loss_func, device, epoch, log_path)
    val_losses.append(val_loss)
    val_accuracies.append(val_acc)
    precisions.append(precision)
    recalls.append(recall)
    f1s.append(f1)

    if val_loss < val_best:
        val_best = val_loss
        best_model_epoch = epoch
        path = os.path.join(config.train_parameters["save_model_dir"], "best.pth")
        torch.save(model.state_dict(), path)
        log(f"Best model saved to {path} (Epoch {epoch}, Val Loss: {val_loss:.4f})", log_path)

    if epoch % 200 == 0:
        path = os.path.join(config.train_parameters["save_model_dir"], f"model_epoch_{epoch}.pth")
        torch.save(model.state_dict(), path)
        log(f"Epoch model saved to {path}", log_path)

end = time.time()
log(f"训练完成，共耗时 {(end - start):.2f} 秒", log_path)
log(f"最佳模型在第 {best_model_epoch} 轮，验证损失: {val_best:.4f}", log_path)

save_list_to_csv(train_losses, os.path.join(config.train_parameters["save_dir"], "train_losses.csv"))
save_list_to_csv(train_accuracies, os.path.join(config.train_parameters["save_dir"], "train_accuracies.csv"))
save_list_to_csv(val_losses, os.path.join(config.train_parameters["save_dir"], "val_losses.csv"))
save_list_to_csv(val_accuracies, os.path.join(config.train_parameters["save_dir"], "val_accuracies.csv"))
save_list_to_csv(precisions, os.path.join(config.train_parameters["save_dir"], "precisions.csv"))
save_list_to_csv(recalls, os.path.join(config.train_parameters["save_dir"], "recalls.csv"))
save_list_to_csv(f1s, os.path.join(config.train_parameters["save_dir"], "f1s.csv"))

plot_func(train_losses, "Train Loss")
plot_func(train_accuracies, "Train Accuracy")
plot_func(val_losses, "Validation Loss")
plot_func(val_accuracies, "Validation Accuracy")
plot_func(precisions, "Bad Class Precision")
plot_func(recalls, "Bad Class Recall")
plot_func(f1s, "Bad Class F1")