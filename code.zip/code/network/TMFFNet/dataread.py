import torch
from torch.utils.data import Dataset, random_split, ConcatDataset
import config
import math


class My_Dataset(Dataset):
    def __init__(self, processed_file):
        data = torch.load(processed_file)
        self.data_m1 = data['m1']
        self.data_m2 = data['m2']
        self.paths = data.get('paths', [""] * len(self.data_m1))

        self.labels = []
        self.is_fake = []
        for label in data['labels']:
            if isinstance(label, (list, tuple)):
                label_val, is_fake = label
            else:
                label_val = label
                is_fake = False
            self.labels.append(label_val)
            self.is_fake.append(is_fake)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return self.data_m1[idx], self.data_m2[idx], self.labels[idx], self.paths[idx], self.is_fake[idx]


def split_dataset(dataset):
    good_indices = [i for i in range(len(dataset)) if dataset.labels[i] == 0]
    bad_indices = [i for i in range(len(dataset)) if dataset.labels[i] == 1 and not dataset.is_fake[i]]
    fake_bad_indices = [i for i in range(len(dataset)) if dataset.labels[i] == 1 and dataset.is_fake[i]]

    generator = torch.Generator().manual_seed(42)

    good_subset = torch.utils.data.Subset(dataset, good_indices)
    total_good = len(good_subset)

    train_good_len = math.ceil(config.train_parameters["train_pro"] * total_good)
    val_good_len = total_good - train_good_len

    train_good, val_good = random_split(
        good_subset,
        [train_good_len, val_good_len],
        generator=generator
    )

    fake_bad_subset = torch.utils.data.Subset(dataset, fake_bad_indices)
    bad_subset = torch.utils.data.Subset(dataset, bad_indices)

    train_set = ConcatDataset([train_good, fake_bad_subset]) if len(fake_bad_subset) > 0 else train_good
    val_set = ConcatDataset([val_good, bad_subset]) if len(bad_subset) > 0 else val_good
    test_set = torch.utils.data.Subset(dataset, [])

    return train_set, val_set, test_set


def load_dataset_by_config():
    base = config.train_parameters["base_dir"]
    use_fake = config.train_parameters["use_fake_datas"]
    filename = f"{'mini_' if config.train_parameters['use_mini'] else ''}processed_dataset"
    filename += "_with_fake.pt" if use_fake else "_nofake.pt"
    dataset_path = f"{base}/{filename}"
    return My_Dataset(dataset_path)