train_parameters = {
    "epoch": 8000,
    "batch": 64,
    "learning_rate": 0.00001,
    "layer_times": 2,
    "device":"cuda:0",
    "train_pro": 0.8,
    "eval_pro": 0.1,
    "num_classes": 2,

    "base_dir": "/ptset/",
    "save_model_dir": r"/EfficientNet/model",
    "save_dir": r"/EfficientNet/plot",
    "log1": r"/EfficientNet/log/log.txt",

    "use_fake_datas": True,
    "use_mini": False,
    "fake_data_train_ratio": 0.9,
    "loss_weights": [1, 1],
    "use_class_weight": True,
    "class_weights": [1, 1],
}
