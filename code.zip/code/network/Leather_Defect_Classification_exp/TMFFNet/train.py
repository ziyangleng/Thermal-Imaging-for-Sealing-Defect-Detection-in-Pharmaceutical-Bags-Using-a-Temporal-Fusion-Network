from net import Net
import dataread
import config
import torch
from torch import nn, optim
from torch.utils.data import DataLoader, WeightedRandomSampler
import time, csv, os
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score
import numpy as np


def save_list_to_csv(input_list, filename):
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        for item in input_list:
            writer.writerow([item])


def plot_func(data, ylabel):
    plt.plot(range(len(data)), data)
    plt.xlabel("Epoch")
    plt.ylabel(ylabel)
    plt.title(f"{ylabel} Curve")
    plt.show()


def log(msg, path):
    print(msg)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(msg + '\n')


def count_label_distribution(dataset, name, log_path):
    counts = [0, 0, 0, 0, 0, 0]
    for idx in range(len(dataset)):
        img, label = dataset.dataset[dataset.indices[idx]]
        counts[int(label)] += 1

    total = sum(counts)
    log(
        f"{name}集: non_defective={counts[0]}, Folding_marks={counts[1]}, Growth_marks={counts[2]}, "
        f"Grain_off={counts[3]}, loose_grains={counts[4]}, pinhole={counts[5]}, 总计={total}",
        log_path
    )


def train_one_epoch(model, train_loader, optimizer, loss_func, device, epoch, log_path):
    model.train()
    loss_sum, correct, total = 0.0, 0, 0

    for batch in train_loader:
        x, y = batch[0].to(device), batch[1].to(device)
        m1 = x
        m2 = x.clone()

        if y.dim() == 2:
            y = y.squeeze(1)

        optimizer.zero_grad()
        pred = model(m1, m2)
        loss = loss_func(pred, y.long())
        loss.backward()
        optimizer.step()

        loss_sum += loss.item()
        correct += (pred.argmax(1) == y).sum().item()
        total += y.size(0)

    avg_loss = loss_sum / len(train_loader) if len(train_loader) > 0 else 0.0
    train_acc = correct / total if total != 0 else 0.0
    log_msg = f"[Epoch {epoch}] Train Loss: {avg_loss:.8f}, Accuracy: {train_acc:.4f}"
    log(log_msg, log_path)
    return avg_loss, train_acc


def validate_one_epoch(model, val_loader, loss_func, device, epoch, log_path):
    model.eval()
    val_loss, val_correct, val_total = 0.0, 0, 0
    all_preds = []
    all_labels = []

    with torch.no_grad():
        for batch in val_loader:
            x, y = batch[0].to(device), batch[1].to(device)
            m1 = x
            m2 = x.clone()

            if y.dim() == 2:
                y = y.squeeze(1)

            pred = model(m1, m2)
            val_loss += loss_func(pred, y.long()).item()
            val_correct += (pred.argmax(1) == y).sum().item()
            val_total += y.size(0)

            all_preds.extend(pred.argmax(1).cpu().numpy())
            all_labels.extend(y.cpu().numpy())

    val_loss_avg = val_loss / len(val_loader) if len(val_loader) != 0 else 0.0
    val_acc = val_correct / val_total if val_total != 0 else 0.0

    if len(all_labels) > 0:
        per_class_precision = precision_score(all_labels, all_preds, labels=[0, 1, 2, 3, 4, 5], average=None,
                                              zero_division=0)
        per_class_recall = recall_score(all_labels, all_preds, labels=[0, 1, 2, 3, 4, 5], average=None, zero_division=0)
        per_class_f1 = f1_score(all_labels, all_preds, labels=[0, 1, 2, 3, 4, 5], average=None, zero_division=0)
        macro_precision = precision_score(all_labels, all_preds, average='macro', zero_division=0)
        macro_recall = recall_score(all_labels, all_preds, average='macro', zero_division=0)
        macro_f1 = f1_score(all_labels, all_preds, average='macro', zero_division=0)
    else:
        per_class_precision = per_class_recall = per_class_f1 = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        macro_precision = macro_recall = macro_f1 = 0.0

    log(f"[Epoch {epoch + 1}] Validation Loss: {val_loss_avg:.8f}, Accuracy: {val_acc:.4f}", log_path)
    cls_names = ["non_defective", "Folding_marks", "Growth_marks", "Grain_off", "loose_grains", "pinhole"]
    for i, name in enumerate(cls_names):
        log(
            f"[Epoch {epoch + 1}] Class {name} - Precision: {per_class_precision[i]:.4f}, "
            f"Recall: {per_class_recall[i]:.4f}, F1: {per_class_f1[i]:.4f}",
            log_path
        )
    log(
        f"[Epoch {epoch + 1}] Macro Avg - Precision: {macro_precision:.4f}, "
        f"Recall: {macro_recall:.4f}, F1: {macro_f1:.4f}",
        log_path
    )

    return val_loss_avg, val_acc


log_path = config.train_parameters["log1"]
os.makedirs(os.path.dirname(log_path), exist_ok=True)
with open(log_path, 'w', encoding='utf-8') as f:
    f.write("训练日志开始\n")

start = time.time()
device = torch.device(config.train_parameters["device"] if torch.cuda.is_available() else "cpu")
log(f"使用设备: {device}", log_path)
log(f"网络双输入配置：m1和m2均为同一张图片", log_path)

model = Net().to(device)
log(f"模型加载完成: {model.__class__.__name__}", log_path)

optimizer = optim.SGD(
    model.parameters(),
    lr=config.train_parameters["learning_rate"],
    momentum=0.9,
    weight_decay=1e-4
)

class_weights = torch.tensor(config.train_parameters["loss_weights"], dtype=torch.float32).to(device)
loss_func = nn.CrossEntropyLoss(weight=class_weights)

train_dataset, val_dataset = dataread.load_dataset()

count_label_distribution(train_dataset, "训练", log_path)
count_label_distribution(val_dataset, "验证", log_path)

if config.train_parameters.get("use_class_weight", False):
    labels = []
    for idx in range(len(train_dataset)):
        _, label = train_dataset.dataset[train_dataset.indices[idx]]
        labels.append(int(label))

    class_weights_cfg = config.train_parameters.get("class_weights", [1.0, 1.0, 1.0, 1.0, 1.0, 1.0])
    class_weights_tensor = torch.tensor(class_weights_cfg, dtype=torch.float32)
    log(f"使用的类别权重: {class_weights_tensor.tolist()}", log_path)

    sample_weights = [float(class_weights_tensor[int(label)]) for label in labels]
    sampler = WeightedRandomSampler(sample_weights, num_samples=len(train_dataset), replacement=True)
    train_loader = DataLoader(train_dataset, batch_size=config.train_parameters["batch"], sampler=sampler,
                              drop_last=True)
else:
    train_loader = DataLoader(train_dataset, batch_size=config.train_parameters["batch"], shuffle=True, drop_last=True)

val_loader = DataLoader(val_dataset, batch_size=config.train_parameters["batch"], shuffle=False, drop_last=True)

val_losses, val_accuracies = [], []
best_model_path = os.path.join(config.train_parameters.get("save_model_dir", config.train_parameters["save_dir"]),
                               "best_mobilenetv3.pth")
val_best = float('inf')

for epoch in range(config.train_parameters["epoch"]):
    train_one_epoch(model, train_loader, optimizer, loss_func, device, epoch + 1, log_path)

    val_loss_avg, val_acc = validate_one_epoch(model, val_loader, loss_func, device, epoch, log_path)
    val_losses.append(val_loss_avg)
    val_accuracies.append(val_acc)

    if val_loss_avg < val_best:
        val_best = val_loss_avg
        os.makedirs(os.path.dirname(best_model_path), exist_ok=True)
        torch.save(model.state_dict(), best_model_path)

end = time.time()
log(f"训练完成，共耗时 {(end - start) / 60:.2f} 分钟", log_path)

save_list_to_csv(val_losses, os.path.join(config.train_parameters["save_dir"], "val_losses.csv"))
save_list_to_csv(val_accuracies, os.path.join(config.train_parameters["save_dir"], "val_accuracies.csv"))
plot_func(val_losses, "Validation Loss")
plot_func(val_accuracies, "Validation Accuracy")

print(f"\n训练完成！")
print(f"最优模型保存至: {best_model_path}")
print(f"验证损失/准确率已保存至: {config.train_parameters['save_dir']}")