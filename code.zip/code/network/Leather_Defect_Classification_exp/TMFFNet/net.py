import config
import torch
import torch.nn as nn
from middle_block import Middle, Block1
from right_block import Right

class Net(nn.Module):
    def __init__(self, num_classes=config.train_parameters["num_classes"], feature_dim=512, gamma_init=0.5, learnable_gamma=False):
        super(Net, self).__init__()
        self.preprocessor = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        )

        self.middle = Middle(Block1, num_classes=feature_dim)
        self.right = Right(feature_dim=feature_dim)
        self.conv3x3_m1 = nn.Sequential(
    nn.Conv2d(64, 32, kernel_size=3, stride=1, padding=1, bias=False),
    nn.BatchNorm2d(32),
    nn.ReLU(inplace=True)
)
        self.conv3x3_m2 = nn.Sequential(
    nn.Conv2d(64, 32, kernel_size=3, stride=1, padding=1, bias=False),
    nn.BatchNorm2d(32),
    nn.ReLU(inplace=True)
)

        if learnable_gamma:
            self.gamma = nn.Parameter(torch.tensor(gamma_init, dtype=torch.float32))
        else:
            self.register_buffer('gamma', torch.tensor(gamma_init, dtype=torch.float32))

        self.classifier = nn.Linear(feature_dim, num_classes)
    def channel_shuffle(self,x, groups):
        batchsize, num_channels, height, width = x.size()
        channels_per_group = num_channels // groups

        x = x.view(batchsize, groups, channels_per_group, height, width)
        x = x.permute(0, 2, 1, 3, 4).contiguous()
        x = x.view(batchsize, -1, height, width)
        return x

    def forward(self, m1, m2):
        m1_feat = self.preprocessor(m1)
        m2_feat = self.preprocessor(m2)
        m1_featr = self.conv3x3_m1(m1_feat)
        m2_featr = self.conv3x3_m2(m2_feat)
        feat = torch.cat([m1_featr, m2_featr], dim=1)
        feat = self.channel_shuffle(feat, 2)

        feat_middle = self.middle(m1_feat, m2_feat)
        feat_right = self.right(feat)
        gamma = torch.sigmoid(self.gamma)
        fusion = gamma * feat_middle + (1 - gamma) * feat_right
        logits = self.classifier(fusion)
        return logits
