import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class DynamicSelfAttentionFusion(nn.Module):
    def __init__(self, in_channels):
        super(DynamicSelfAttentionFusion, self).__init__()
        self.q_conv = nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False)
        self.k_conv = nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False)
        self.v_conv = nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False)

    def forward(self, x, y):
        q = F.adaptive_avg_pool2d(self.q_conv(x), 1).flatten(1)
        k = F.adaptive_avg_pool2d(self.k_conv(y), 1).flatten(1)
        v_x = self.v_conv(x)
        v_y = self.v_conv(y)

        score1 = (q * k).sum(dim=1, keepdim=True)
        score2 = (k * q).sum(dim=1, keepdim=True)
        attn = F.softmax(torch.cat([score1, score2], dim=1), dim=1)

        a1 = attn[:, 0].view(-1, 1, 1, 1)
        a2 = attn[:, 1].view(-1, 1, 1, 1)
        out = a1 * v_x + a2 * v_y
        return out

class GhostModule(nn.Module):
    def __init__(self, inp, oup, kernel_size=1, ratio=2, dw_size=3, stride=1, relu=True):
        super(GhostModule, self).__init__()
        self.oup = oup
        init_channels = math.ceil(oup / ratio)
        new_channels = init_channels * (ratio - 1)

        self.primary_conv = nn.Sequential(
            nn.Conv2d(inp, init_channels, kernel_size, stride, kernel_size // 2, bias=False),
            nn.BatchNorm2d(init_channels),
            nn.ReLU() if relu else nn.Sequential(),
        )

        self.cheap_operation = nn.Sequential(
            nn.Conv2d(init_channels, new_channels, dw_size, 1, dw_size // 2, groups=init_channels, bias=False),
            nn.BatchNorm2d(new_channels),
            nn.ReLU() if relu else nn.Sequential(),
        )

    def forward(self, x):
        x1 = self.primary_conv(x)
        x2 = self.cheap_operation(x1)
        out = torch.cat([x1, x2], dim=1)
        return out[:, :self.oup, :, :]

class GlobalSelfAttentionForTwoFeatures(nn.Module):
    def __init__(self, channels_per_layer):
        super(GlobalSelfAttentionForTwoFeatures, self).__init__()
        self.attentive_fusions = nn.ModuleList([
            DynamicSelfAttentionFusion(ch) for ch in channels_per_layer
        ])

    def forward(self, x_list, y_list):
        return [fusion(x_list[i], y_list[i]) for i, fusion in enumerate(self.attentive_fusions)]

class Block1(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super(Block1, self).__init__()
        self.relu = nn.ReLU()

        self.block = nn.Sequential(
            GhostModule(in_channels, in_channels, stride=stride),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(),
            nn.Conv2d(in_channels, out_channels, 3, 1, 1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Conv2d(out_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
        )

        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels)
            )

    def forward(self, x):
        identity = x
        x = self.block(x)
        x = x + self.shortcut(identity)
        return self.relu(x)

class Middle(nn.Module):
    def __init__(self, Block1, num_classes=2):
        super(Middle, self).__init__()
        self.layer1_x = self.make_layer(Block1, 64, 64, 2, final_stride=2)
        self.layer2_x = self.make_layer(Block1, 64, 128, 3, final_stride=2)
        self.layer3_x = self.make_layer(Block1, 128, 256, 4, final_stride=2)
        self.layer4_x = self.make_layer(Block1, 256, 512, 2, final_stride=2)

        self.layer1_y = self.make_layer(Block1, 64, 64, 2, final_stride=2)
        self.layer2_y = self.make_layer(Block1, 64, 128, 3, final_stride=2)
        self.layer3_y = self.make_layer(Block1, 128, 256, 4, final_stride=2)
        self.layer4_y = self.make_layer(Block1, 256, 512, 2, final_stride=2)

        self.global_attention = GlobalSelfAttentionForTwoFeatures(
            channels_per_layer=[64, 128, 256, 512]
        )

        self.fc = nn.Linear(512, num_classes)

    def make_layer(self, block, in_channels, out_channels, num_blocks, final_stride=2):
        strides = [1] * (num_blocks - 1) + [final_stride]
        layers = []
        for i, stride in enumerate(strides):
            layers.append(block(in_channels, out_channels, stride))
            in_channels = out_channels
        return nn.Sequential(*layers)

    def forward(self, x, y):
        x1 = self.layer1_x(x)
        y1 = self.layer1_y(y)
        x2 = self.layer2_x(x1)
        y2 = self.layer2_y(y1)
        x3 = self.layer3_x(x2)
        y3 = self.layer3_y(y2)
        x4 = self.layer4_x(x3)
        y4 = self.layer4_y(y3)

        fused_feats = self.global_attention([x1, x2, x3, x4], [y1, y2, y3, y4])

        final_feat = fused_feats[-1]
        final_feat = F.adaptive_avg_pool2d(final_feat, (1, 1)).flatten(start_dim=1)
        final_feat = self.fc(final_feat)
        return final_feat