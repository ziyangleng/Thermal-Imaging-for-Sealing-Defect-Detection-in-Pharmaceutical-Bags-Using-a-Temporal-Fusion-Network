import torch
import torch.nn as nn

class SeModule(nn.Module):
    def __init__(self, in_size, reduction=4):
        super(SeModule, self).__init__()
        expand_size = max(in_size // reduction, 8)
        self.se = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_size, expand_size, 1, bias=False),
            nn.BatchNorm2d(expand_size),
            nn.ReLU(inplace=True),
            nn.Conv2d(expand_size, in_size, 1, bias=False),
            nn.Hardsigmoid()
        )

    def forward(self, x):
        attn = self.se(x)
        out = x * attn
        return out

class Block2(nn.Module):
    def __init__(self, in_channels, growth_rate, num_layers, name=""):
        super(Block2, self).__init__()
        self.name = name
        self.layers = nn.ModuleList()
        self.growth_rate = growth_rate

        for i in range(num_layers):
            layer_in_channels = in_channels + i * growth_rate
            self.layers.append(nn.Sequential(
                nn.BatchNorm2d(layer_in_channels),
                nn.ReLU(inplace=True),
                nn.Conv2d(layer_in_channels, growth_rate, 3, padding=1, bias=False)
            ))

    def forward(self, x):
        features = [x]
        for i, layer in enumerate(self.layers):
            layer_input = torch.cat(features, dim=1)
            layer_output = layer(layer_input)
            features.append(layer_output)

        out = torch.cat(features, dim=1)
        return out

class TransitionLayer(nn.Module):
    def __init__(self, in_channels, out_channels, name=""):
        super(TransitionLayer, self).__init__()
        self.name = name
        self.transition = nn.Sequential(
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, out_channels, 1, bias=False),
            nn.AvgPool2d(2, stride=2)
        )

    def forward(self, x):
        out = self.transition(x)
        return out

class Right(nn.Module):
    def __init__(self, feature_dim=1000, reduction=4):
        super(Right, self).__init__()
        self.reduction = reduction

        self.init_conv = nn.Sequential(
            nn.Conv2d(64, 64, kernel_size=7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        )

        self.features = nn.Sequential(
            SeModule(in_size=64, reduction=reduction),
            Block2(64, growth_rate=0, num_layers=0, name="SEDenseBlock1"),
            TransitionLayer(in_channels=64, out_channels=64, name="Transition1"),
            SeModule(in_size=64, reduction=reduction),
            Block2(64, growth_rate=8, num_layers=8, name="SEDenseBlock2"),
            TransitionLayer(in_channels=128, out_channels=128, name="Transition2"),
            SeModule(in_size=128, reduction=reduction),
            Block2(128, growth_rate=8, num_layers=16, name="SEDenseBlock3"),
            TransitionLayer(in_channels=256, out_channels=256, name="Transition3"),
            SeModule(in_size=256, reduction=reduction),
            Block2(256, growth_rate=16, num_layers=16, name="SEDenseBlock4"),
        )

        final_channels = 512

        self.global_pool = nn.AdaptiveAvgPool2d((1, 1))

        self.feature_mapping = nn.Sequential(
            nn.Linear(final_channels, feature_dim),
            nn.BatchNorm1d(feature_dim),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        x = self.init_conv(x)
        x = self.features(x)
        x = self.global_pool(x)
        x = torch.flatten(x, 1)
        x = self.feature_mapping(x)
        return x