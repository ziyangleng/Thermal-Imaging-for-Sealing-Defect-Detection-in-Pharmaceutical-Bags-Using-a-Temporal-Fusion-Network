import dataread
import config
import torch
from torch import nn, optim
from torch.utils.data import DataLoader, WeightedRandomSampler
import time, csv, os
import matplotlib.pyplot as plt
from sklearn.metrics import precision_score, recall_score, f1_score
from torchvision import models


def get_vit_model(num_classes=6, pretrained=False, version='b_16', image_size=224):
    vit_models = {
        'b_16': models.vit_b_16,
        'b_32': models.vit_b_32,
        'l_16': models.vit_l_16,
        'l_32': models.vit_l_32,
        'h_14': models.vit_h_14,
    }

    if version not in vit_models:
        raise ValueError(f"不支持的ViT版本: {version}. 请选择 {list(vit_models.keys())}")

    if pretrained:
        model = vit_models[version](weights=models.ViT_B_16_Weights.IMAGENET1K_V1)
    else:
        from torchvision.models.vision_transformer import VisionTransformer
        configs = {
            'b_16': {'patch_size': 16, 'num_layers': 12, 'num_heads': 12, 'hidden_dim': 768, 'mlp_dim': 3072},
            'b_32': {'patch_size': 32, 'num_layers': 12, 'num_heads': 12, 'hidden_dim': 768, 'mlp_dim': 3072},
            'l_16': {'patch_size': 16, 'num_layers': 24, 'num_heads': 16, 'hidden_dim': 1024, 'mlp_dim': 4096},
            'l_32': {'patch_size': 32, 'num_layers': 24, 'num_heads': 16, 'hidden_dim': 1024, 'mlp_dim': 4096},
            'h_14': {'patch_size': 14, 'num_layers': 32, 'num_heads': 16, 'hidden_dim': 1280, 'mlp_dim': 5120},
        }
        cfg = configs[version]
        model = VisionTransformer(
            image_size=image_size,
            patch_size=cfg['patch_size'],
            num_layers=cfg['num_layers'],
            num_heads=cfg['num_heads'],
            hidden_dim=cfg['hidden_dim'],
            mlp_dim=cfg['mlp_dim'],
            num_classes=1000
        )

    num_features = model.heads.head.in_features
    model.heads.head = nn.Linear(num_features, num_classes)

    return model


def save_list_to_csv(input_list, filename):
    os.makedirs(os.path.dirname(filename), exist_ok=True)
    with open(filename, 'w', newline='') as f:
        writer = csv.writer(f)
        for item in input_list:
            writer.writerow([item])


def plot_func(data, ylabel):
    plt.plot(range(len(data)), data)
    plt.xlabel("Epoch")
    plt.ylabel(ylabel)
    plt.title(f"{ylabel} Curve")
    plt.show()


def log(msg, path):
    print(msg)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'a', encoding='utf-8') as f:
        f.write(msg + '\n')


def count_label_distribution(dataset, name, log_path):
    counts = [0, 0, 0, 0, 0, 0]
    for sample in dataset:
        img, label = sample
        counts[int(label)] += 1

    total = sum(counts)
    log(
        f"{name}集: non_defective={counts[0]}, Folding_marks={counts[1]}, Growth_marks={counts[2]}, "
        f"Grain_off={counts[3]}, loose_grains={counts[4]}, pinhole={counts[5]}, 总计={total}",
        log_path
    )


log_path = config.train_parameters["log1"]
with open(log_path, 'w', encoding='utf-8') as f:
    f.write("训练日志开始\n")

start = time.time()
device = torch.device(config.train_parameters["device"] if torch.cuda.is_available() else "cpu")
print(f"当前使用设备: {device}")

model = get_vit_model(
    num_classes=6,
    pretrained=False,
    version='b_16'
).to(device)

optimizer = optim.SGD(
    model.parameters(),
    lr=config.train_parameters["learning_rate"],
    momentum=0.9,
    weight_decay=1e-4
)

class_weights = torch.tensor(config.train_parameters["loss_weights"], dtype=torch.float32).to(device)
loss_func = nn.CrossEntropyLoss(weight=class_weights)

train_dataset, val_dataset = dataread.load_dataset()

count_label_distribution(train_dataset, "训练", log_path)
count_label_distribution(val_dataset, "验证", log_path)

if config.train_parameters.get("use_class_weight", False):
    labels = [train_dataset[i][1] for i in range(len(train_dataset))]
    class_weights_cfg = config.train_parameters.get("class_weights", [1.0, 1.0, 1.0, 1.0, 1.0, 1.0])
    class_weights_tensor = torch.tensor(class_weights_cfg, dtype=torch.float32)
    log(f"使用的类别权重: {class_weights_tensor.tolist()}", log_path)
    sample_weights = [float(class_weights_tensor[int(label)]) for label in labels]
    sampler = WeightedRandomSampler(sample_weights, num_samples=len(train_dataset), replacement=True)
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.train_parameters["batch"],
        sampler=sampler,
        drop_last=True
    )
else:
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.train_parameters["batch"],
        shuffle=True,
        drop_last=True
    )

val_loader = DataLoader(
    val_dataset,
    batch_size=config.train_parameters["batch"],
    shuffle=False,
    drop_last=True
)

val_losses, val_accuracies = [], []
total_epoch = config.train_parameters["epoch"]

for epoch in range(total_epoch):
    model.train()
    loss_sum, correct, total = 0.0, 0, 0
    for batch in train_loader:
        x, y = batch[0].to(device), batch[1].to(device)
        if y.dim() > 1:
            y = y.squeeze()

        optimizer.zero_grad()
        pred = model(x)
        loss = loss_func(pred, y.long())
        loss.backward()
        optimizer.step()

        loss_sum += loss.item()
        correct += (pred.argmax(1) == y).sum().item()
        total += y.size(0)

    avg_loss = loss_sum / len(train_loader) if len(train_loader) > 0 else 0.0
    train_acc = correct / total if total != 0 else 0.0
    log(f"[Epoch {epoch + 1}/{total_epoch}] Train Loss: {avg_loss:.8f}, Accuracy: {train_acc:.4f}", log_path)

    model.eval()
    val_loss, val_correct, val_total = 0.0, 0, 0
    all_preds = []
    all_labels = []
    with torch.no_grad():
        for batch in val_loader:
            x, y = batch[0].to(device), batch[1].to(device)
            if y.dim() > 1:
                y = y.squeeze()

            pred = model(x)
            val_loss += loss_func(pred, y.long()).item()
            val_correct += (pred.argmax(1) == y).sum().item()
            val_total += y.size(0)

            all_preds.extend(pred.argmax(1).cpu().numpy())
            all_labels.extend(y.cpu().numpy())

    val_loss_avg = val_loss / len(val_loader) if len(val_loader) != 0 else 0.0
    val_acc = val_correct / val_total if val_total != 0 else 0.0
    val_losses.append(val_loss_avg)
    val_accuracies.append(val_acc)

    if len(all_labels) > 0:
        per_class_precision = precision_score(all_labels, all_preds, labels=[0, 1, 2, 3, 4, 5], average=None,
                                              zero_division=0)
        per_class_recall = recall_score(all_labels, all_preds, labels=[0, 1, 2, 3, 4, 5], average=None, zero_division=0)
        per_class_f1 = f1_score(all_labels, all_preds, labels=[0, 1, 2, 3, 4, 5], average=None, zero_division=0)
        macro_precision = precision_score(all_labels, all_preds, average='macro', zero_division=0)
        macro_recall = recall_score(all_labels, all_preds, average='macro', zero_division=0)
        macro_f1 = f1_score(all_labels, all_preds, average='macro', zero_division=0)
    else:
        per_class_precision = per_class_recall = per_class_f1 = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        macro_precision = macro_recall = macro_f1 = 0.0

    log(f"[Epoch {epoch + 1}] Validation Loss: {val_loss_avg:.8f}, Accuracy: {val_acc:.4f}", log_path)
    cls_names = ["non_defective", "Folding_marks", "Growth_marks", "Grain_off", "loose_grains", "pinhole"]
    for i, name in enumerate(cls_names):
        log(
            f"[Epoch {epoch + 1}] Class {name} - Precision: {per_class_precision[i]:.4f}, "
            f"Recall: {per_class_recall[i]:.4f}, F1: {per_class_f1[i]:.4f}",
            log_path
        )
    log(
        f"[Epoch {epoch + 1}] Macro Avg - Precision: {macro_precision:.4f}, "
        f"Recall: {macro_recall:.4f}, F1: {macro_f1:.4f}",
        log_path
    )

end = time.time()
log(f"训练完成，共耗时 {(end - start) / 60:.2f} 分钟", log_path)

save_list_to_csv(val_losses, os.path.join(config.train_parameters["save_dir"], "val_losses.csv"))
save_list_to_csv(val_accuracies, os.path.join(config.train_parameters["save_dir"], "val_accuracies.csv"))

plot_func(val_losses, "Validation Loss")
plot_func(val_accuracies, "Validation Accuracy")

print(f"\n训练完成！")
print(f"验证损失/准确率已保存至: {config.train_parameters['save_dir']}")
print(f"模型按200epoch间隔保存至: {config.train_parameters['save_model_dir']}")