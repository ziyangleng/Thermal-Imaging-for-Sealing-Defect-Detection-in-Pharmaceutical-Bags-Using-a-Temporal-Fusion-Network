csv_path = "\dataset\dataset_foreign\bad\12_2943-2948_1.csv";
highlight_range = [125, 135];
global_min = 0; global_max = 180;
poly_order = 4;
search_half_height = 5;
max_jump = 8;

data = readmatrix(csv_path);
[rows, cols] = size(data);
if rows == 768 && cols == 256
    block_size = 256;
elseif rows == 1536 && cols == 640
    block_size = 512;
else
    error('CSV 文件尺寸不符合预期（应为768x256或1536x640）');
end
img1 = data(1:block_size, :);

img_norm = nonlinearNormalize(img1, global_min, global_max, highlight_range);
figure; imagesc(img_norm); colormap(jet); axis image off;
title('框选感兴趣区域');
rect = round(getrect);
roi = img1(rect(2):rect(2)+rect(4), rect(1):rect(1)+rect(3));
[rows_roi, cols_roi] = size(roi);

curve_x = []; curve_y = [];

for c = 1:cols_roi
    if isempty(curve_y)
        [~, y_local] = max(roi(:, c));
        curve_y(end+1) = y_local + rect(2);
        curve_x(end+1) = c + rect(1);
    else
        prev_y = curve_y(end) - rect(2);
        y_min = max(1, round(prev_y - search_half_height));
        y_max = min(rows_roi, round(prev_y + search_half_height));

        if y_min >= y_max
            continue;
        end

        [~, rel_idx] = max(roi(y_min:y_max, c));
        y_new = y_min + rel_idx - 1;

        if abs(y_new - prev_y) > max_jump
            continue;
        end

        curve_y(end+1) = y_new + rect(2);
        curve_x(end+1) = c + rect(1);
    end
end

if numel(unique(curve_x)) <= poly_order
    error('有效点数太少，无法拟合');
end
p = polyfit(curve_x, curve_y, poly_order);
x_fit = linspace(min(curve_x), max(curve_x), 200);
y_fit = polyval(p, x_fit);

figure; imagesc(img_norm); colormap(jet); axis image off; hold on;
title('原图及拟合曲线');
plot(x_fit, y_fit, 'r-', 'LineWidth', 2);

scatter(curve_x, curve_y, 36, 'ko', 'filled');

fprintf('\n拟合曲线表达式（%d 阶多项式）：\n', poly_order);
expr = 'y = ';
for k = 1:poly_order+1
    coeff = p(k);
    power = poly_order - (k - 1);
    if coeff == 0
        continue;
    end
    if k > 1 && coeff > 0
        expr = [expr, '+'];
    end
    if power == 0
        expr = [expr, sprintf('%.4f', coeff)];
    elseif power == 1
        expr = [expr, sprintf('%.4fx', coeff)];
    else
        expr = [expr, sprintf('%.4fx^%d', coeff, power)];
    end
end
disp(expr);

function img_out = nonlinearNormalize(img, min_val, max_val, focus_range)
    low = focus_range(1); high = focus_range(2);
    img_out = zeros(size(img));
    idx1 = img <= low;
    idx2 = img > low & img <= high;
    idx3 = img > high;
    img_out(idx1) = 0.2 * (img(idx1) - min_val) / (low - min_val + eps);
    img_out(idx2) = 0.2 + 0.6 * (img(idx2) - low) / (high - low + eps);
    img_out(idx3) = 0.8 + 0.2 * (img(idx3) - high) / (max_val - high + eps);
    img_out = max(0, min(1, img_out));
end