basic_folder = '\dataset\dataset_foreign\good';
save_folder = '\dataset\dataset_foreign\fake_bad';
if ~exist(save_folder, 'dir')
    mkdir(save_folder);
end

n = 2;
minVal = 1.00;
maxVal = 1.022;
blurSize = 3;
blurSigma = 1;
gauss_sigma = 5;

highlight_range = [125, 135];
global_min = 0; global_max = 180;
gradient_limit = 20;

distance_threshold = 20;
length_threshold = 40;

batch_num = 1200;

for batch_idx = 1:batch_num
    fprintf('开始生成第 %d 批次...\n', batch_idx);
    canvas = generateRandomDefect();
    [img1, img2, img3] = combinedProcess(n, minVal, maxVal, blurSize, blurSigma, canvas, basic_folder, distance_threshold, length_threshold,gauss_sigma);
    
    [rows, cols] = size(img1);
    if rows == 512 && cols == 640
        combined_img = [img1; img2; img3];
    elseif rows == 512 && cols == 512
        combined_img = [img1; img2; img3];
    elseif rows == 256 && cols == 256
        combined_img = [img1; img2; img3];
    else
        error('未知图像尺寸，无法合并');
    end
    
    save_filename = sprintf('fake2_1_%03d.csv', batch_idx);
    save_path = fullfile(save_folder, save_filename);
    writematrix(combined_img, save_path);
    
    fprintf('第 %d 批次生成完成，已保存至 %s\n', batch_idx, save_path);
end

function canvas = generateRandomDefect()
    folder = 'D:\code\matlab\data_analyze\fitted_curve';
    flist = dir(fullfile(folder,'*.txt'));

    coeffs = [];

    for i = 1:length(flist)
        fname = fullfile(folder, flist(i).name);
        txt = fileread(fname);

        expr = '曲线方程: y = ([\d\.\+\-\*x\^\ ]+)';
        tokens = regexp(txt, expr, 'tokens');
        if isempty(tokens), continue; end

        eqstr = strrep(tokens{1}{1},' ','');

        p = regexp(eqstr, '([+-]?\d*\.?\d+)[*]?x\^3([+-]\d*\.?\d+)[*]?x\^2([+-]\d*\.?\d+)[*]?x([+-]\d*\.?\d+)', 'tokens');

        if isempty(p)
            error(['文件' fname '中曲线方程无法识别: ' eqstr]);
        end
        p = p{1};
        coeffs(end+1,:) = str2double(p);
    end

    N = size(coeffs,1);
    num = randi([1,min(3,N)]);
    sel = randperm(N,num);

    mean_coeff = mean(coeffs(sel,:),1);

    mean_coeff(1) = mean_coeff(1) * 1000;
    mean_coeff(2) = mean_coeff(2) * 100;
    mean_coeff(3) = mean_coeff(3) * 0.1;
    mean_coeff(4) = mean_coeff(4) * 0.01;

    str = sprintf('%.4fx^3%+.4fx^2%+.4fx%+.4f',mean_coeff);

    canvas_height = 20;
    canvas_width = randi([80, 120]);
    x = linspace(-1000, 1000, canvas_width);

    y = mean_coeff(1)*x.^3 + mean_coeff(2)*x.^2 + mean_coeff(3)*x + mean_coeff(4);

    y_normalized = (y - min(y)) / (max(y) - min(y));

    main_canvas = zeros(canvas_height, canvas_width);
    
    for col = 1:canvas_width
        row = round(y_normalized(col) * (canvas_height - 1)) + 1;
        main_canvas(row, col) = 1;
    end
    
    if N > 1
        sel2 = randperm(N,1);
        second_coeff = coeffs(sel2,:);
        second_coeff(1) = second_coeff(1) * 500;
        second_coeff(2) = second_coeff(2) * 50;
        second_coeff(3) = second_coeff(3) * 0.05;
        second_coeff(4) = second_coeff(4) * 0.005;
        
        second_width = round(canvas_width * 0.6);
        x2 = linspace(-800, 800, second_width);
        y2 = second_coeff(1)*x2.^3 + second_coeff(2)*x2.^2 + second_coeff(3)*x2 + second_coeff(4);
        y2_normalized = (y2 - min(y2)) / (max(y2) - min(y2));
        
        second_canvas = zeros(canvas_height, second_width);
        for col = 1:second_width
            row = round(y2_normalized(col) * (canvas_height - 1)) + 1;
            second_canvas(row, col) = 1;
        end
        
        spacing = 20;
        combined_width = canvas_width + spacing + second_width;
        canvas = zeros(canvas_height, combined_width);
        
        canvas(:, 1:canvas_width) = main_canvas;
        
        canvas(:, (canvas_width+spacing+1):end) = second_canvas;
    else
        canvas = main_canvas;
    end
    
    canvas = padarray(canvas, [8 8], 0, 'both');
end

function [line_midpoint] = findLineMidpoint(img, distance_threshold, length_threshold)
    img_gray = mat2gray(img);
    edge_img = edge(img_gray, 'sobel');
    CC = bwconncomp(edge_img);
    filtered_edge = false(size(edge_img));
    
    for k = 1:CC.NumObjects
        if numel(CC.PixelIdxList{k}) <= length_threshold
            filtered_edge(CC.PixelIdxList{k}) = true;
        end
    end
    
    [y_pts, x_pts] = find(filtered_edge);
    
    if isempty(x_pts)
        line_midpoint = [];
        return;
    end
    
    [x_sorted, sort_idx] = sort(x_pts);
    y_sorted = y_pts(sort_idx);
    
    max_count = 0;
    best_idx = [];
    
    N = length(x_sorted);
    
    for i = 1:N
        x_i = x_sorted(i);
        y_i = y_sorted(i);
    
        dx = abs(x_sorted - x_i);
        dy = abs(y_sorted - y_i);
        in_range = find(dx <= distance_threshold & dy <= distance_threshold);
    
        if numel(in_range) > max_count
            max_count = numel(in_range);
            best_idx = in_range;
        end
    end
    
    if isempty(best_idx)
        line_midpoint = [];
        return;
    end
    
    x_dense = x_sorted(best_idx);
    y_dense = y_sorted(best_idx);
    
    x_mid = (min(x_dense) + max(x_dense)) / 2;
    y_mid = (min(y_dense) + max(y_dense)) / 2;
    
    line_midpoint = [x_mid, y_mid];
end

function [img1, img2, img3] = combinedProcess(n, minVal, maxVal, blurSize, blurSigma, defect_data, basic_folder, distance_threshold, length_threshold,gauss_sigma)
    if ~exist(basic_folder, 'dir')
        error('基础文件夹不存在: %s', basic_folder);
    end
    
    curve_relative_coords = loadCurveRelativeCoords();
    if isempty(curve_relative_coords)
        error('没有找到曲线相对坐标');
    end
    
    basic_files = dir(fullfile(basic_folder, '*.csv'));
    if isempty(basic_files)
        error('在文件夹 %s 中没有找到CSV文件', basic_folder);
    end
    rand_index = randi(length(basic_files));
    basic_file = fullfile(basic_folder, basic_files(rand_index).name);
    data = readmatrix(basic_file);
    [total_rows, total_cols] = size(data);
    if total_rows == 1536 && total_cols == 640
        single_height = 512;
        img1 = data(1:single_height, :);
        img2 = data(single_height+1:2*single_height, :);
        img3 = data(2*single_height+1:end, :);
    elseif total_rows == 1536 && total_cols == 512
        single_height = 512;
        img1 = data(1:single_height, :);
        img2 = data(single_height+1:2*single_height, :);
        img3 = data(2*single_height+1:end, :);
    elseif total_rows == 768 && total_cols == 256
        single_height = 256;
        img1 = data(1:single_height, :);
        img2 = data(single_height+1:2*single_height, :);
        img3 = data(2*single_height+1:end, :);
    else
        error('CSV文件尺寸不支持，实际 %dx%d，支持的尺寸：1536x640, 1536x512, 768x256', total_rows, total_cols);
    end

    [rows, cols] = find(defect_data == 1);
    newDefectData = ones(size(defect_data));
    for i = 1:length(rows)
        row = rows(i);
        col = cols(i);
        halfWidth = floor(n/2);
        for r = max(1, row - halfWidth):min(size(defect_data, 1), row + halfWidth)
            for c = max(1, col - halfWidth):min(size(defect_data, 2), col + halfWidth)
                dr = abs(r - row);
                if halfWidth > 0
                    t = dr / halfWidth * 2 - 1;
                    gradientValue = minVal + (maxVal - minVal) * exp(-t^2 / (2 * gauss_sigma^2));
                else
                    gradientValue = maxVal;
                end
                gradientValue = max(minVal, min(maxVal, gradientValue));
                newDefectData(r, c) = gradientValue;
            end
        end
    end
    
    h = fspecial('gaussian', [blurSize blurSize], blurSigma);
    blurredDefectData = imfilter(newDefectData, h, 'full');
    for r = 1:size(blurredDefectData, 1)
        rowData = blurredDefectData(r, :);
        blurredDefectData(r, :) = smoothdata(rowData, 'movmean', 5);
    end
    blurredDefectData = max(1, min(maxVal, blurredDefectData));

    images = {img1, img2, img3};
    line_midpoint = findLineMidpoint(images{1}, distance_threshold, length_threshold);
    if isempty(line_midpoint)
        fprintf('未找到合适的直线，跳过当前批次\n');
        img1 = []; img2 = []; img3 = [];
        return;
    end
    rand_coord_idx = randi(size(curve_relative_coords, 1));
    relative_coord = curve_relative_coords(rand_coord_idx, :);
    curve_center_x = line_midpoint(1) + relative_coord(1);
    curve_center_y = line_midpoint(2) + relative_coord(2);

    [heightDefect, widthDefect] = size(blurredDefectData);
    startX = round(curve_center_x - widthDefect/2);
    startY = round(curve_center_y - heightDefect/2);

    curve_mid_x = curve_center_x;
    curve_mid_y = curve_center_y;
    full_image_width = size(images{1}, 2);
    full_image_height = size(images{1}, 1);

    if curve_mid_x < 50
        move_distance = 50 - curve_mid_x;
        curve_center_x = curve_center_x + move_distance;
        curve_center_y = curve_center_y;
        startX = round(curve_center_x - widthDefect/2);
        startY = round(curve_center_y - heightDefect/2);
        startX = max(1, min(startX, full_image_width - widthDefect + 1));
    end

    Gx = imfilter(double(img1), fspecial('sobel')', 'replicate');
    proj = sum(abs(Gx),1);
    th = 0.5 * max(proj);
    left_x = find(proj > th, 1, 'first');
    right_x = find(proj > th, 1, 'last');
    if isempty(left_x), left_x=1; end
    if isempty(right_x), right_x=size(img1,2); end

    for img_idx = 1:3
        current_img = images{img_idx};
        
        defect_left = startX;
        defect_right = startX + size(blurredDefectData, 2) - 1;
        
        if defect_right < left_x || defect_left > right_x
            continue;
        end
        
        defect_crop_left = max(0, left_x - defect_left) + 1;
        defect_crop_right = size(blurredDefectData, 2) - max(0, defect_right - right_x);
        
        cropped_defect = blurredDefectData(:, defect_crop_left:defect_crop_right);
        [cropped_height, cropped_width] = size(cropped_defect);
        
        insert_left = max(left_x, defect_left);
        insert_top = max(1, startY);
        
        insert_bottom = min(insert_top + cropped_height - 1, size(current_img,1));
        insert_right = min(insert_left + cropped_width - 1, size(current_img,2));
        
        cropped_height = insert_bottom - insert_top + 1;
        cropped_width = insert_right - insert_left + 1;
        cropped_defect = cropped_defect(1:cropped_height, 1:cropped_width);
        
        for y = 1:cropped_height
            for x = 1:cropped_width
                if cropped_defect(y, x) ~= 0
                    current_img(insert_top + y - 1, insert_left + x - 1) = ...
                        current_img(insert_top + y - 1, insert_left + x - 1) * cropped_defect(y, x);
                end
            end
        end
        
        images{img_idx} = current_img;
    end
    
    img1 = images{1};
    img2 = images{2};
    img3 = images{3};
end

function showOneImageWithGradients(img, idx, gradient_limit, highlight_range, global_min, global_max, fname)
    Gx = imfilter(img, fspecial('sobel')', 'replicate');
    Gy = imfilter(img, fspecial('sobel'), 'replicate');
    
    Gx_abs = abs(Gx); Gx_abs(Gx_abs > gradient_limit) = NaN;
    Gy_abs = abs(Gy); Gy_abs(Gy_abs > gradient_limit) = NaN;
    
    img_norm = nonlinearNormalize(img, global_min, global_max, highlight_range);
    
    fig = figure('Name', sprintf('%s - 图 %d', fname, idx), ...
                 'NumberTitle', 'off', ...
                 'WindowState', 'maximized');
    
    subplot(1,3,1);
    imagesc(img_norm);
    axis image off;
    colormap(gca, jet);
    colorbar;
    title('温度图');
    
    subplot(1,3,2);
    imagesc(Gx_abs);
    axis image off;
    colormap(gca, jet);
    caxis([0 gradient_limit]);
    colorbar;
    title('X 方向梯度');
    
    subplot(1,3,3);
    imagesc(Gy_abs);
    axis image off;
    colormap(gca, jet);
    caxis([0 gradient_limit]);
    colorbar;
    title('Y 方向梯度');
    
    uiwait(fig);
end

function img_out = nonlinearNormalize(img, min_val, max_val, focus_range)
    low = focus_range(1); high = focus_range(2);
    img_out = zeros(size(img));
    idx1 = img <= low;
    idx2 = img > low & img <= high;
    idx3 = img > high;
    img_out(idx1) = 0.2 * (img(idx1) - min_val) / (low - min_val + eps);
    img_out(idx2) = 0.2 + 0.6 * (img(idx2) - low) / (high - low + eps);
    img_out(idx3) = 0.8 + 0.2 * (img(idx3) - high) / (max_val - high + eps);
    img_out = max(0, min(1, img_out));
end

function [curve_relative_coords] = loadCurveRelativeCoords()
    folder = 'D:\code\matlab\data_analyze\fitted_curve';
    flist = dir(fullfile(folder,'*.txt'));
    
    curve_relative_coords = [];
    
    for i = 1:length(flist)
        fname = fullfile(folder, flist(i).name);
        txt = fileread(fname);
        
        expr = '曲线中点相对坐标: \(([+-]?\d+\.?\d*), ([+-]?\d+\.?\d*)\)';
        tokens = regexp(txt, expr, 'tokens');
        
        if ~isempty(tokens)
            x_rel = str2double(tokens{1}{1});
            y_rel = str2double(tokens{1}{2});
            curve_relative_coords(end+1, :) = [x_rel, y_rel];
        end
    end
end